<!--
───────────────────────────────────────────────
  Property of CKS  © 2025
  Manifested by Freedom
───────────────────────────────────────────────

File: Permissions.md

Description: Caps required per route; mapping to UI tabs for Manager users
Function: Map capabilities to backend endpoints and frontend visibility.
Importance: Keeps RBAC consistent across tiers.
Connects to: 002_rbac.sql, requireCaps.ts, frontend/config.v1.json.
Notes: Placeholder — detailed matrix TBD.
-->

