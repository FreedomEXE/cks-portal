<!--
───────────────────────────────────────────────
  Property of CKS  © 2025
  Manifested by Freedom
───────────────────────────────────────────────

File: Changelog.md

Description: Human log of schema changes (why + impact).
Function: Track DB changes over time for Manager-related schema.
Importance: Aids troubleshooting and team coordination.
Connects to: Migrations.md, migrations/*.sql.
Notes: Placeholder — entries to be added as changes occur.
-->

