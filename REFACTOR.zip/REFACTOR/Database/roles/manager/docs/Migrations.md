<!--
───────────────────────────────────────────────
  Property of CKS  © 2025
  Manifested by Freedom
───────────────────────────────────────────────

File: Migrations.md

Description: How to run/rollback migrations; naming/versioning policy.
Function: Document DB change workflow for Manager module.
Importance: Prevents drift and maintains DB integrity.
Connects to: migrations/*.sql, Seeds.md, Changelog.md.
Notes: Placeholder instructions — to be detailed later.
-->

