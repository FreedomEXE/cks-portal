<!--
───────────────────────────────────────────────
  Property of CKS  © 2025
  Manifested by Freedom
───────────────────────────────────────────────

File: Permissions.md

Description: Tab visibility vs. server caps, with scenarios. for Manager Users
Function: Document how UI requires[] maps to backend capabilities.
Importance: Keeps RBAC consistent from server to client.
Connects to: backend Permissions.md, config.v1.json.
Notes: Placeholder — scenarios and mappings TBD.
-->

